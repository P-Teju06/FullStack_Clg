// ── Table filter ──────────────────────────────────────────
function filterTable() {
  const input = document.getElementById('searchInput');
  if (!input) return;
  const filter = input.value.toLowerCase();
  const table = document.getElementById('appTable');
  if (!table) return;
  const rows = table.querySelectorAll('tbody tr');
  rows.forEach(row => {
    const text = row.textContent.toLowerCase();
    row.style.display = text.includes(filter) ? '' : 'none';
  });
}

// ── Top search redirect to jobs page ──────────────────────
document.addEventListener('DOMContentLoaded', () => {
  const topSearch = document.getElementById('topSearch');
  if (topSearch) {
    topSearch.addEventListener('keydown', e => {
      if (e.key === 'Enter' && topSearch.value.trim()) {
        window.location.href = '/jobs?keyword=' + encodeURIComponent(topSearch.value.trim());
      }
    });
  }

  // ── Show company field for EMPLOYER role on register ────
  const roleSelect = document.getElementById('roleSelect');
  const companyGroup = document.getElementById('companyGroup');
  if (roleSelect && companyGroup) {
    const toggle = () => {
      companyGroup.style.display = roleSelect.value === 'EMPLOYER' ? 'block' : 'none';
    };
    roleSelect.addEventListener('change', toggle);
    toggle();
  }

  // ── Auto-dismiss alerts after 4s ────────────────────────
  document.querySelectorAll('.alert').forEach(alert => {
    setTimeout(() => {
      alert.style.transition = 'opacity 0.5s';
      alert.style.opacity = '0';
      setTimeout(() => alert.remove(), 500);
    }, 4000);
  });
});
