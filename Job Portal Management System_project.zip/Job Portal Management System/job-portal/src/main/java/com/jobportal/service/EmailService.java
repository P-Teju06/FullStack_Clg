package com.jobportal.service;

import lombok.RequiredArgsConstructor;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class EmailService {

    private final JavaMailSender mailSender;

    public void sendShortlistNotification(String toEmail, String name, String jobTitle) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(toEmail);
        message.setSubject("Congratulations! You've been shortlisted");
        message.setText("Dear " + name + ",\n\n" +
                "You have been shortlisted for the position: " + jobTitle + ".\n" +
                "Please log in to your Job Portal account for more details.\n\n" +
                "Best regards,\nJob Portal Team");
        mailSender.send(message);
    }
}
