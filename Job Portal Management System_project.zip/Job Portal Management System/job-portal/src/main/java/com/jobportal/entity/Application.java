package com.jobportal.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "applications")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Application {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    private Status status = Status.PENDING;

    private LocalDateTime appliedAt = LocalDateTime.now();

    @Column(columnDefinition = "TEXT")
    private String coverLetter;

    // Many applications -> one job
    @ManyToOne
    @JoinColumn(name = "job_id")
    private Job job;

    // Many applications -> one student
    @ManyToOne
    @JoinColumn(name = "applicant_id")
    private User applicant;

    public enum Status {
        PENDING, SHORTLISTED, REJECTED
    }
}
