package com.jobportal.service;

import com.jobportal.entity.Application;
import com.jobportal.entity.Job;
import com.jobportal.entity.User;
import com.jobportal.repository.ApplicationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ApplicationService {

    private final ApplicationRepository applicationRepository;
    private final EmailService emailService;

    public Application apply(Job job, User applicant, String coverLetter) {
        applicationRepository.findByJobAndApplicant(job, applicant).ifPresent(a -> {
            throw new RuntimeException("You have already applied for this job");
        });
        Application app = new Application();
        app.setJob(job);
        app.setApplicant(applicant);
        app.setCoverLetter(coverLetter);
        return applicationRepository.save(app);
    }

    public List<Application> getApplicationsByUser(User user) {
        return applicationRepository.findByApplicant(user);
    }

    public List<Application> getApplicationsByJob(Job job) {
        return applicationRepository.findByJob(job);
    }

    public Application updateStatus(Long applicationId, Application.Status status) {
        Application app = applicationRepository.findById(applicationId)
                .orElseThrow(() -> new RuntimeException("Application not found"));
        app.setStatus(status);
        applicationRepository.save(app);

        // Send email notification on shortlist
        if (status == Application.Status.SHORTLISTED) {
            emailService.sendShortlistNotification(
                app.getApplicant().getEmail(),
                app.getApplicant().getFullName(),
                app.getJob().getTitle()
            );
        }
        return app;
    }

    public long countByJob(Job job) {
        return applicationRepository.countByJob(job);
    }

    public long countShortlisted(Job job) {
        return applicationRepository.countByJobAndStatus(job, Application.Status.SHORTLISTED);
    }
}
