package com.jobportal.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import java.util.List;

@Entity
@Table(name = "users")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Size(min = 2, max = 100)
    private String fullName;

    @NotBlank
    @Email
    @Column(unique = true)
    private String email;

    @NotBlank
    @Size(min = 6)
    private String password;

    @Enumerated(EnumType.STRING)
    private Role role; // STUDENT, EMPLOYER, ADMIN

    private String phone;
    private String location;
    private String resumePath;

    // Extended profile fields
    private String bio;
    private String skills;           // comma-separated
    private String linkedinUrl;
    private String githubUrl;
    private String portfolioUrl;
    private String currentJobTitle;
    private String experienceYears;  // e.g. "3"
    private String education;        // e.g. "B.Tech CSE, Anna University"
    private String languages;        // e.g. "English, Tamil, Hindi"
    private String dateOfBirth;      // e.g. "1999-05-12"
    private String gender;

    // For employers
    private String companyName;

    @OneToMany(mappedBy = "employer", cascade = CascadeType.ALL)
    private List<Job> postedJobs;

    @OneToMany(mappedBy = "applicant", cascade = CascadeType.ALL)
    private List<Application> applications;

    public enum Role {
        STUDENT, EMPLOYER, ADMIN
    }
}
