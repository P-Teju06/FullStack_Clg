package com.jobportal.config;

import com.jobportal.entity.Job;
import com.jobportal.entity.User;
import com.jobportal.repository.JobRepository;
import com.jobportal.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.ArrayList;
import java.util.List;

@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final JobRepository jobRepository;
    private final PasswordEncoder passwordEncoder;
    private final JdbcTemplate jdbcTemplate;

    @Override
    public void run(String... args) {
        // Data already seeded - skip on subsequent startups
        Integer userCount = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM users", Integer.class);
        if (userCount != null && userCount > 0) {
            System.out.println("✅ Database already seeded (" + userCount + " users, skipping)");
            return;
        }

        // ── Users ──────────────────────────────────────────────
        if (!userRepository.existsByEmail("admin@jobportal.com"))
            userRepository.save(makeUser("Admin", "admin@jobportal.com", "admin123", User.Role.ADMIN, null));

        User it    = getOrCreate("techcorp@demo.com",    "TechCorp HR",       "demo123", User.Role.EMPLOYER, "TechCorp India");
        User fin   = getOrCreate("financegroup@demo.com","Finance Group HR",  "demo123", User.Role.EMPLOYER, "Finance Group Ltd");
        User hlth  = getOrCreate("healthplus@demo.com",  "HealthPlus HR",     "demo123", User.Role.EMPLOYER, "HealthPlus Hospitals");
        User edu   = getOrCreate("eduworld@demo.com",    "EduWorld HR",       "demo123", User.Role.EMPLOYER, "EduWorld Academy");
        User eng   = getOrCreate("buildtech@demo.com",   "BuildTech HR",      "demo123", User.Role.EMPLOYER, "BuildTech Engineering");
        User mkt   = getOrCreate("brandco@demo.com",     "BrandCo HR",        "demo123", User.Role.EMPLOYER, "BrandCo Marketing");
        User legal = getOrCreate("lawfirm@demo.com",     "LawFirm HR",        "demo123", User.Role.EMPLOYER, "Justice Law Associates");
        User hotel = getOrCreate("grandhotel@demo.com",  "Grand Hotel HR",    "demo123", User.Role.EMPLOYER, "Grand Hotel Group");
        User media = getOrCreate("mediahub@demo.com",    "MediaHub HR",       "demo123", User.Role.EMPLOYER, "MediaHub Studios");
        User logis = getOrCreate("logisticsco@demo.com", "LogisticsCo HR",    "demo123", User.Role.EMPLOYER, "LogisticsCo India");

        getOrCreate("employer@demo.com", "Demo Employer", "demo123", User.Role.EMPLOYER, "Demo Corp");
        getOrCreate("student@demo.com",  "Demo Student",  "demo123", User.Role.STUDENT,  null);

        System.out.println("✅ employer@demo.com / demo123  |  student@demo.com / demo123");

        Integer jobCount = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM jobs", Integer.class);
        if (jobCount != null && jobCount > 0) return;

        List<Job> jobs = new ArrayList<>();

        // ── IT (30 jobs) ──────────────────────────────────────
        jobs.add(job("Java Backend Developer",       "IT","Bangalore","Mid",    "Build REST APIs with Spring Boot and microservices.",                        "Java,Spring Boot,MySQL,Docker,REST APIs",              70000,110000,it));
        jobs.add(job("React Frontend Developer",     "IT","Hyderabad","Entry",  "Build responsive UIs using React.js.",                                       "React.js,JavaScript,HTML5,CSS3,Git",                  45000, 70000,it));
        jobs.add(job("Full Stack Developer",         "IT","Pune",     "Mid",    "End-to-end web application development.",                                    "Node.js,React,MongoDB,Express,AWS",                   80000,130000,it));
        jobs.add(job("Data Scientist",               "IT","Mumbai",   "Senior", "Analyze datasets and build ML models.",                                      "Python,TensorFlow,Pandas,SQL,ML",                    120000,180000,it));
        jobs.add(job("DevOps Engineer",              "IT","Chennai",  "Mid",    "Manage CI/CD pipelines and cloud infra.",                                    "Docker,Kubernetes,Jenkins,AWS,Linux",                  90000,140000,it));
        jobs.add(job("Android Developer",            "IT","Delhi",    "Entry",  "Build and publish Android apps.",                                            "Kotlin,Android SDK,Firebase,REST APIs",                40000, 65000,it));
        jobs.add(job("Cybersecurity Analyst",        "IT","Bangalore","Senior", "Protect infrastructure from cyber threats.",                                 "Network Security,SIEM,Penetration Testing,Python",    130000,200000,it));
        jobs.add(job("Cloud Architect",              "IT","Hyderabad","Senior", "Design scalable cloud solutions on AWS/Azure.",                              "AWS,Azure,Terraform,Kubernetes,Microservices",        150000,220000,it));
        jobs.add(job("UI/UX Designer",               "IT","Pune",     "Entry",  "Design intuitive user interfaces.",                                          "Figma,Adobe XD,Wireframing,Prototyping,CSS",           35000, 55000,it));
        jobs.add(job("Machine Learning Engineer",    "IT","Mumbai",   "Mid",    "Develop and deploy ML models for production.",                               "Python,Scikit-learn,TensorFlow,MLflow,SQL",           100000,160000,it));
        jobs.add(job("Python Developer",             "IT","Bangalore","Mid",    "Develop backend services and automation scripts.",                           "Python,Django,Flask,PostgreSQL,REST APIs",             65000,100000,it));
        jobs.add(job("iOS Developer",                "IT","Delhi",    "Mid",    "Build and maintain iOS applications.",                                       "Swift,Xcode,UIKit,CoreData,REST APIs",                 60000, 95000,it));
        jobs.add(job("Database Administrator",       "IT","Chennai",  "Senior", "Manage and optimize database systems.",                                      "MySQL,PostgreSQL,Oracle,Performance Tuning,Backup",    90000,140000,it));
        jobs.add(job("QA Engineer",                  "IT","Hyderabad","Entry",  "Test software applications and report bugs.",                                "Selenium,JUnit,TestNG,Manual Testing,JIRA",            35000, 55000,it));
        jobs.add(job("Blockchain Developer",         "IT","Mumbai",   "Senior", "Build decentralized applications on blockchain.",                            "Solidity,Ethereum,Web3.js,Smart Contracts,Node.js",   140000,220000,it));
        jobs.add(job("Data Engineer",                "IT","Pune",     "Mid",    "Build and maintain data pipelines.",                                         "Apache Spark,Kafka,Python,SQL,AWS Glue",               85000,130000,it));
        jobs.add(job("Scrum Master",                 "IT","Bangalore","Mid",    "Facilitate agile ceremonies and remove blockers.",                           "Agile,Scrum,JIRA,Confluence,Leadership",               70000,110000,it));
        jobs.add(job("Network Engineer",             "IT","Delhi",    "Mid",    "Design and maintain network infrastructure.",                                "Cisco,CCNA,Routing,Switching,Firewalls",               60000, 95000,it));
        jobs.add(job("Embedded Systems Engineer",    "IT","Chennai",  "Mid",    "Develop firmware for embedded devices.",                                     "C,C++,RTOS,ARM,Microcontrollers",                      65000,100000,it));
        jobs.add(job("Technical Writer",             "IT","Hyderabad","Entry",  "Write technical documentation and API guides.",                              "Technical Writing,Markdown,API Docs,Confluence",       30000, 50000,it));
        jobs.add(job("SAP Consultant",               "IT","Mumbai",   "Senior", "Implement and configure SAP modules.",                                       "SAP FICO,SAP MM,SAP SD,ABAP,Business Analysis",       120000,180000,it));
        jobs.add(job("Angular Developer",            "IT","Pune",     "Mid",    "Build enterprise web apps with Angular.",                                    "Angular,TypeScript,RxJS,HTML5,CSS3",                   65000,100000,it));
        jobs.add(job("Site Reliability Engineer",    "IT","Bangalore","Senior", "Ensure reliability and performance of production systems.",                  "Linux,Python,Kubernetes,Prometheus,Grafana",          130000,200000,it));
        jobs.add(job("Business Analyst",             "IT","Delhi",    "Mid",    "Bridge gap between business and technology teams.",                          "Requirements Gathering,SQL,JIRA,Agile,Visio",          60000, 95000,it));
        jobs.add(job("Game Developer",               "IT","Hyderabad","Mid",    "Develop mobile and PC games.",                                               "Unity,C#,Unreal Engine,3D Modeling,Game Physics",     70000,110000,it));
        jobs.add(job("Power BI Developer",           "IT","Chennai",  "Mid",    "Build interactive dashboards and reports.",                                  "Power BI,DAX,SQL,Excel,Data Modeling",                 60000, 95000,it));
        jobs.add(job("Salesforce Developer",         "IT","Mumbai",   "Mid",    "Customize and develop on Salesforce platform.",                              "Salesforce,Apex,LWC,SOQL,CRM",                        80000,130000,it));
        jobs.add(job("IT Support Engineer",          "IT","Pune",     "Entry",  "Provide technical support to end users.",                                    "Windows,Linux,Networking,Troubleshooting,ITIL",        25000, 40000,it));
        jobs.add(job("Golang Developer",             "IT","Bangalore","Mid",    "Build high-performance backend services in Go.",                             "Go,Microservices,Docker,gRPC,PostgreSQL",              85000,130000,it));
        jobs.add(job("AI Research Scientist",        "IT","Delhi",    "Senior", "Research and develop cutting-edge AI algorithms.",                           "Python,Deep Learning,NLP,PyTorch,Research",           160000,250000,it));

        // ── Finance (20 jobs) ─────────────────────────────────
        jobs.add(job("Financial Analyst",            "Finance","Mumbai",   "Mid",    "Analyze financial data and prepare reports.",                                "Excel,Financial Modeling,SAP,Power BI,Accounting",    60000, 95000,fin));
        jobs.add(job("Investment Banker",            "Finance","Delhi",    "Senior", "Manage M&A transactions and capital markets.",                              "Financial Analysis,Valuation,Bloomberg,Excel,CFA",   150000,250000,fin));
        jobs.add(job("Chartered Accountant",         "Finance","Chennai",  "Mid",    "Handle auditing, tax compliance and reporting.",                             "Tally,GST,Income Tax,Auditing,MS Excel",               70000,110000,fin));
        jobs.add(job("Risk Manager",                 "Finance","Bangalore","Senior", "Identify and mitigate financial risks.",                                     "Risk Assessment,Basel III,Excel,SQL,FRM",             120000,180000,fin));
        jobs.add(job("Accounts Executive",           "Finance","Hyderabad","Entry",  "Manage day-to-day accounting operations.",                                   "Tally,MS Excel,GST,Bookkeeping,Accounting",            25000, 40000,fin));
        jobs.add(job("Tax Consultant",               "Finance","Pune",     "Mid",    "Provide tax planning and compliance services.",                              "Income Tax,GST,Tax Planning,Excel,Tally",              55000, 85000,fin));
        jobs.add(job("Credit Analyst",               "Finance","Mumbai",   "Mid",    "Evaluate creditworthiness of loan applicants.",                              "Credit Analysis,Excel,Financial Modeling,Banking",     55000, 85000,fin));
        jobs.add(job("Portfolio Manager",            "Finance","Delhi",    "Senior", "Manage investment portfolios for clients.",                                  "Portfolio Management,CFA,Bloomberg,Excel,Equity",    130000,200000,fin));
        jobs.add(job("Equity Research Analyst",      "Finance","Bangalore","Mid",    "Research and analyze equity markets.",                                       "Equity Research,Bloomberg,Excel,Financial Modeling",   70000,110000,fin));
        jobs.add(job("Compliance Officer",           "Finance","Chennai",  "Mid",    "Ensure regulatory compliance across operations.",                            "Compliance,RBI Guidelines,SEBI,Legal,Reporting",       65000,100000,fin));
        jobs.add(job("Treasury Manager",             "Finance","Hyderabad","Senior", "Manage company cash flow and treasury operations.",                          "Treasury,Cash Management,Forex,Banking,Excel",        110000,160000,fin));
        jobs.add(job("Actuarial Analyst",            "Finance","Pune",     "Mid",    "Analyze financial risk using mathematics and statistics.",                   "Actuarial Science,Statistics,Excel,R,Risk Modeling",   70000,110000,fin));
        jobs.add(job("Payroll Specialist",           "Finance","Mumbai",   "Entry",  "Process employee payroll and statutory compliance.",                         "Payroll,Tally,Excel,PF,ESI,TDS",                       28000, 45000,fin));
        jobs.add(job("Audit Manager",                "Finance","Delhi",    "Senior", "Lead internal and external audit engagements.",                              "Auditing,IFRS,Excel,Risk Assessment,Leadership",      100000,150000,fin));
        jobs.add(job("Financial Controller",         "Finance","Bangalore","Senior", "Oversee all financial operations and reporting.",                            "Financial Reporting,GAAP,SAP,Leadership,Excel",       130000,200000,fin));
        jobs.add(job("Insurance Advisor",            "Finance","Chennai",  "Entry",  "Advise clients on insurance products and policies.",                         "Insurance,Sales,Communication,CRM,MS Office",          20000, 40000,fin));
        jobs.add(job("Forex Trader",                 "Finance","Mumbai",   "Mid",    "Trade foreign exchange markets for the firm.",                               "Forex,Bloomberg,Risk Management,Technical Analysis",   80000,140000,fin));
        jobs.add(job("Wealth Manager",               "Finance","Delhi",    "Senior", "Provide comprehensive wealth management services.",                          "Wealth Management,CFA,Investments,Client Relations",  120000,200000,fin));
        jobs.add(job("Cost Accountant",              "Finance","Hyderabad","Mid",    "Analyze and control production and operational costs.",                      "Cost Accounting,Tally,Excel,CMA,Budgeting",            50000, 80000,fin));
        jobs.add(job("Finance Manager",              "Finance","Pune",     "Senior", "Lead financial planning and analysis for the business.",                     "Financial Planning,Excel,SAP,Leadership,Budgeting",   100000,160000,fin));

        // ── Healthcare (20 jobs) ──────────────────────────────
        jobs.add(job("Staff Nurse",                  "Healthcare","Chennai",  "Entry",  "Provide patient care and assist doctors.",                                   "Patient Care,IV Administration,BLS,Nursing",           25000, 40000,hlth));
        jobs.add(job("Medical Lab Technician",       "Healthcare","Mumbai",   "Entry",  "Perform diagnostic tests and maintain lab equipment.",                       "Lab Testing,Microscopy,Blood Analysis,LIMS",           22000, 38000,hlth));
        jobs.add(job("Hospital Administrator",       "Healthcare","Delhi",    "Senior", "Oversee hospital operations and compliance.",                                "Healthcare Management,Operations,HR,Budgeting",        90000,140000,hlth));
        jobs.add(job("Physiotherapist",              "Healthcare","Bangalore","Mid",    "Treat patients with physical disabilities.",                                  "Physiotherapy,Rehabilitation,Exercise Therapy",        40000, 65000,hlth));
        jobs.add(job("Pharmacist",                   "Healthcare","Hyderabad","Mid",    "Dispense medications and counsel patients.",                                  "Pharmacology,Drug Dispensing,Patient Counseling",      45000, 70000,hlth));
        jobs.add(job("Radiologist",                  "Healthcare","Pune",     "Senior", "Interpret medical imaging studies.",                                          "Radiology,MRI,CT Scan,X-Ray,Medical Imaging",        150000,250000,hlth));
        jobs.add(job("General Physician",            "Healthcare","Chennai",  "Mid",    "Diagnose and treat common illnesses.",                                        "Clinical Medicine,Patient Care,Diagnosis,OPD",         80000,130000,hlth));
        jobs.add(job("Dentist",                      "Healthcare","Mumbai",   "Mid",    "Provide dental care and treatment.",                                          "Dentistry,Oral Surgery,Patient Care,BDS",              70000,120000,hlth));
        jobs.add(job("Nutritionist",                 "Healthcare","Delhi",    "Entry",  "Provide dietary advice and nutrition plans.",                                 "Nutrition,Diet Planning,Patient Counseling,BSc",       25000, 45000,hlth));
        jobs.add(job("Occupational Therapist",       "Healthcare","Bangalore","Mid",    "Help patients regain daily living skills.",                                   "Occupational Therapy,Rehabilitation,Patient Care",     45000, 70000,hlth));
        jobs.add(job("Medical Coder",                "Healthcare","Hyderabad","Entry",  "Assign medical codes for billing and records.",                               "ICD-10,CPT Coding,Medical Terminology,CPC",            22000, 38000,hlth));
        jobs.add(job("Healthcare IT Analyst",        "Healthcare","Pune",     "Mid",    "Manage hospital information systems.",                                        "HIS,EMR,HL7,SQL,Healthcare IT",                        55000, 85000,hlth));
        jobs.add(job("Surgeon",                      "Healthcare","Chennai",  "Senior", "Perform surgical procedures.",                                                "Surgery,MBBS,MS,Patient Care,OT Management",          200000,400000,hlth));
        jobs.add(job("Psychiatrist",                 "Healthcare","Mumbai",   "Senior", "Diagnose and treat mental health disorders.",                                 "Psychiatry,MBBS,MD,Patient Care,Counseling",          180000,350000,hlth));
        jobs.add(job("Paramedic",                    "Healthcare","Delhi",    "Entry",  "Provide emergency medical care.",                                             "Emergency Care,BLS,ACLS,Patient Assessment",           20000, 35000,hlth));
        jobs.add(job("Clinical Research Associate",  "Healthcare","Bangalore","Mid",    "Monitor clinical trials and ensure compliance.",                              "Clinical Trials,GCP,ICH Guidelines,Data Management",   55000, 90000,hlth));
        jobs.add(job("Biomedical Engineer",          "Healthcare","Hyderabad","Mid",    "Maintain and repair medical equipment.",                                      "Biomedical Equipment,Electronics,Maintenance,CAD",     50000, 80000,hlth));
        jobs.add(job("Health Informatics Specialist","Healthcare","Pune",     "Mid",    "Manage health data and information systems.",                                 "Health Informatics,SQL,EMR,Data Analysis,HL7",         60000, 95000,hlth));
        jobs.add(job("Veterinarian",                 "Healthcare","Chennai",  "Mid",    "Provide medical care to animals.",                                            "Veterinary Medicine,BVSc,Animal Care,Surgery",         55000, 90000,hlth));
        jobs.add(job("Ophthalmic Technician",        "Healthcare","Mumbai",   "Entry",  "Assist ophthalmologists in eye care procedures.",                             "Ophthalmology,Slit Lamp,Refraction,Patient Care",      20000, 35000,hlth));

        // ── Education (20 jobs) ───────────────────────────────
        jobs.add(job("Software Trainer",             "Education","Bangalore","Mid",    "Deliver training on Java, Python and web tech.",                             "Java,Python,Teaching,Curriculum Design",               40000, 65000,edu));
        jobs.add(job("Mathematics Teacher",          "Education","Delhi",    "Entry",  "Teach mathematics to high school students.",                                  "Mathematics,Teaching,Lesson Planning,MS Office",       25000, 40000,edu));
        jobs.add(job("E-Learning Developer",         "Education","Mumbai",   "Mid",    "Design interactive e-learning modules.",                                      "Articulate Storyline,LMS,Instructional Design,HTML",   55000, 85000,edu));
        jobs.add(job("Academic Counselor",           "Education","Chennai",  "Entry",  "Guide students on career paths.",                                             "Counseling,Communication,MS Office,Student Engagement",20000, 35000,edu));
        jobs.add(job("Principal",                    "Education","Hyderabad","Senior", "Lead school administration and faculty.",                                      "Leadership,Administration,Curriculum Development",     80000,120000,edu));
        jobs.add(job("Science Teacher",              "Education","Pune",     "Entry",  "Teach Physics, Chemistry and Biology.",                                       "Science,Teaching,Lab Management,Lesson Planning",      22000, 38000,edu));
        jobs.add(job("English Language Trainer",     "Education","Bangalore","Entry",  "Teach spoken and written English.",                                           "English,Communication,Teaching,IELTS,Soft Skills",     20000, 35000,edu));
        jobs.add(job("Special Education Teacher",    "Education","Delhi",    "Mid",    "Teach students with learning disabilities.",                                   "Special Education,IEP,Patience,Communication",         35000, 55000,edu));
        jobs.add(job("University Professor",         "Education","Mumbai",   "Senior", "Teach and conduct research at university level.",                             "Research,PhD,Teaching,Publications,Subject Expertise",100000,160000,edu));
        jobs.add(job("Curriculum Designer",          "Education","Chennai",  "Mid",    "Design and develop educational curricula.",                                    "Curriculum Design,Instructional Design,LMS,Content",   50000, 80000,edu));
        jobs.add(job("School Librarian",             "Education","Hyderabad","Entry",  "Manage school library and resources.",                                        "Library Management,Cataloging,MS Office,Organization", 18000, 30000,edu));
        jobs.add(job("Education Coordinator",        "Education","Pune",     "Mid",    "Coordinate academic programs and activities.",                                "Coordination,MS Office,Communication,Planning",        40000, 65000,edu));
        jobs.add(job("Preschool Teacher",            "Education","Bangalore","Entry",  "Teach and care for preschool children.",                                      "Early Childhood Education,Patience,Creativity,Care",   15000, 28000,edu));
        jobs.add(job("Corporate Trainer",            "Education","Delhi",    "Mid",    "Deliver soft skills and leadership training.",                                 "Training,Soft Skills,Leadership,Communication,PPT",    55000, 90000,edu));
        jobs.add(job("Exam Controller",              "Education","Mumbai",   "Mid",    "Manage examination processes and results.",                                    "Exam Management,MS Office,Coordination,Accuracy",      40000, 65000,edu));
        jobs.add(job("Education Technology Analyst", "Education","Chennai",  "Mid",    "Analyze and implement EdTech solutions.",                                      "EdTech,LMS,Data Analysis,Technology,Communication",    50000, 80000,edu));
        jobs.add(job("Yoga Instructor",              "Education","Hyderabad","Entry",  "Teach yoga and wellness practices.",                                           "Yoga,Wellness,Teaching,Certification,Communication",   15000, 30000,edu));
        jobs.add(job("Sports Coach",                 "Education","Pune",     "Entry",  "Coach students in sports and physical education.",                            "Sports,Coaching,Physical Education,Fitness",           18000, 35000,edu));
        jobs.add(job("Research Assistant",           "Education","Bangalore","Entry",  "Assist professors in academic research.",                                      "Research,Data Collection,MS Office,Writing,Analysis",  20000, 35000,edu));
        jobs.add(job("Distance Learning Coordinator","Education","Delhi",    "Mid",    "Manage online and distance learning programs.",                                "Distance Learning,LMS,Coordination,Communication",     45000, 70000,edu));

        // ── Engineering (20 jobs) ─────────────────────────────
        jobs.add(job("Civil Engineer",               "Engineering","Delhi",    "Mid",    "Design and supervise construction projects.",                                "AutoCAD,Structural Design,Project Management,MS Project",55000, 85000,eng));
        jobs.add(job("Mechanical Engineer",          "Engineering","Pune",     "Mid",    "Design mechanical systems for manufacturing.",                               "SolidWorks,AutoCAD,Manufacturing,Thermodynamics",      50000, 80000,eng));
        jobs.add(job("Electrical Engineer",          "Engineering","Chennai",  "Entry",  "Design electrical systems and ensure safety.",                               "Circuit Design,AutoCAD Electrical,PLC,SCADA",          35000, 55000,eng));
        jobs.add(job("Site Engineer",                "Engineering","Mumbai",   "Entry",  "Supervise construction activities on site.",                                  "Site Management,AutoCAD,Quality Control,Safety",       30000, 50000,eng));
        jobs.add(job("Project Manager",              "Engineering","Bangalore","Senior", "Lead large-scale engineering projects.",                                      "Project Management,PMP,MS Project,Risk Management",   130000,200000,eng));
        jobs.add(job("Quality Control Engineer",     "Engineering","Hyderabad","Mid",    "Ensure products meet quality standards.",                                     "Quality Control,Six Sigma,ISO Standards,Testing",      60000, 90000,eng));
        jobs.add(job("Structural Engineer",          "Engineering","Delhi",    "Mid",    "Design structural systems for buildings.",                                    "STAAD Pro,AutoCAD,Structural Analysis,RCC Design",     60000, 95000,eng));
        jobs.add(job("Chemical Engineer",            "Engineering","Pune",     "Mid",    "Design chemical processes and equipment.",                                    "Chemical Process,HYSYS,AutoCAD,Safety,Thermodynamics", 55000, 90000,eng));
        jobs.add(job("Aerospace Engineer",           "Engineering","Bangalore","Senior", "Design and test aircraft and spacecraft.",                                    "CATIA,MATLAB,Aerodynamics,FEA,CFD",                   130000,200000,eng));
        jobs.add(job("Environmental Engineer",       "Engineering","Chennai",  "Mid",    "Develop solutions for environmental problems.",                               "Environmental Impact,AutoCAD,GIS,Water Treatment",     55000, 85000,eng));
        jobs.add(job("Petroleum Engineer",           "Engineering","Mumbai",   "Senior", "Develop methods for extracting oil and gas.",                                 "Reservoir Engineering,Drilling,Petrel,Eclipse",       150000,250000,eng));
        jobs.add(job("Instrumentation Engineer",     "Engineering","Hyderabad","Mid",    "Design and maintain instrumentation systems.",                                "PLC,SCADA,DCS,Instrumentation,AutoCAD",                60000, 95000,eng));
        jobs.add(job("Production Engineer",          "Engineering","Delhi",    "Mid",    "Optimize manufacturing production processes.",                                "Lean Manufacturing,Six Sigma,AutoCAD,Production",      55000, 85000,eng));
        jobs.add(job("Maintenance Engineer",         "Engineering","Pune",     "Entry",  "Maintain and repair industrial machinery.",                                   "Mechanical Maintenance,Hydraulics,Pneumatics,PLC",     30000, 50000,eng));
        jobs.add(job("Welding Engineer",             "Engineering","Chennai",  "Mid",    "Oversee welding operations and quality.",                                     "Welding,AWS,ASME,Quality Control,AutoCAD",             50000, 80000,eng));
        jobs.add(job("Geotechnical Engineer",        "Engineering","Bangalore","Mid",    "Analyze soil and rock for construction projects.",                            "Geotechnical Analysis,AutoCAD,Soil Testing,GIS",       60000, 95000,eng));
        jobs.add(job("Fire Safety Engineer",         "Engineering","Mumbai",   "Mid",    "Design fire protection systems for buildings.",                               "Fire Safety,NFPA,AutoCAD,Risk Assessment,NBC",         60000, 95000,eng));
        jobs.add(job("Piping Engineer",              "Engineering","Hyderabad","Mid",    "Design piping systems for industrial plants.",                                "PDMS,AutoCAD,Piping Design,ASME,Stress Analysis",      65000,100000,eng));
        jobs.add(job("Textile Engineer",             "Engineering","Delhi",    "Entry",  "Develop and improve textile manufacturing processes.",                        "Textile Technology,Quality Control,CAD,Production",    28000, 45000,eng));
        jobs.add(job("Robotics Engineer",            "Engineering","Pune",     "Senior", "Design and program robotic systems.",                                         "ROS,Python,C++,Robotics,Computer Vision",             120000,190000,eng));

        // ── Marketing (20 jobs) ───────────────────────────────
        jobs.add(job("Digital Marketing Manager",   "Marketing","Mumbai",   "Mid",    "Plan and execute digital campaigns.",                                        "SEO,Google Ads,Facebook Ads,Analytics,Content",        65000,100000,mkt));
        jobs.add(job("Content Writer",              "Marketing","Delhi",    "Entry",  "Create engaging blog posts and marketing copy.",                             "Content Writing,SEO,WordPress,Social Media",           20000, 35000,mkt));
        jobs.add(job("Brand Manager",               "Marketing","Bangalore","Senior", "Develop and execute brand strategy.",                                         "Brand Strategy,Market Research,Campaign Management",  110000,160000,mkt));
        jobs.add(job("Social Media Executive",      "Marketing","Hyderabad","Entry",  "Manage company social media accounts.",                                       "Instagram,Facebook,Canva,Content Creation",            18000, 30000,mkt));
        jobs.add(job("Market Research Analyst",     "Marketing","Chennai",  "Mid",    "Conduct market research and competitive analysis.",                           "Market Research,Excel,SPSS,Survey Tools",              50000, 75000,mkt));
        jobs.add(job("SEO Specialist",              "Marketing","Pune",     "Mid",    "Optimize websites for search engine rankings.",                               "SEO,Google Analytics,Keyword Research,Ahrefs",         45000, 75000,mkt));
        jobs.add(job("Email Marketing Specialist",  "Marketing","Mumbai",   "Mid",    "Design and execute email marketing campaigns.",                               "Email Marketing,Mailchimp,HubSpot,Copywriting,A/B",    50000, 80000,mkt));
        jobs.add(job("Performance Marketing Lead",  "Marketing","Delhi",    "Senior", "Drive growth through paid marketing channels.",                               "Google Ads,Facebook Ads,Analytics,ROI,Attribution",    90000,140000,mkt));
        jobs.add(job("PR Manager",                  "Marketing","Bangalore","Senior", "Manage public relations and media communications.",                           "PR,Media Relations,Press Releases,Crisis Management", 100000,150000,mkt));
        jobs.add(job("Graphic Designer",            "Marketing","Hyderabad","Entry",  "Create visual content for marketing campaigns.",                              "Photoshop,Illustrator,Canva,Figma,Branding",           22000, 40000,mkt));
        jobs.add(job("Video Editor",                "Marketing","Chennai",  "Entry",  "Edit and produce marketing videos.",                                          "Premiere Pro,After Effects,DaVinci Resolve,YouTube",   20000, 38000,mkt));
        jobs.add(job("Influencer Marketing Manager","Marketing","Pune",     "Mid",    "Manage influencer partnerships and campaigns.",                               "Influencer Marketing,Social Media,Negotiation,CRM",    55000, 90000,mkt));
        jobs.add(job("Growth Hacker",               "Marketing","Mumbai",   "Mid",    "Drive rapid user acquisition and retention.",                                 "Growth Hacking,Analytics,A/B Testing,SQL,Python",      70000,110000,mkt));
        jobs.add(job("Copywriter",                  "Marketing","Delhi",    "Entry",  "Write compelling copy for ads and campaigns.",                                "Copywriting,Creativity,SEO,Social Media,Branding",     18000, 35000,mkt));
        jobs.add(job("Marketing Analyst",           "Marketing","Bangalore","Mid",    "Analyze marketing data to improve campaigns.",                                "Excel,Google Analytics,SQL,Power BI,Reporting",        55000, 85000,mkt));
        jobs.add(job("Product Marketing Manager",   "Marketing","Hyderabad","Senior", "Drive go-to-market strategy for products.",                                   "Product Marketing,GTM Strategy,Positioning,Analytics", 100000,160000,mkt));
        jobs.add(job("Event Manager",               "Marketing","Chennai",  "Mid",    "Plan and execute corporate events and campaigns.",                            "Event Planning,Vendor Management,Budgeting,Logistics",  55000, 85000,mkt));
        jobs.add(job("E-commerce Manager",          "Marketing","Pune",     "Mid",    "Manage online store operations and growth.",                                  "E-commerce,Amazon,Flipkart,SEO,Analytics",             65000,100000,mkt));
        jobs.add(job("Marketing Intern",            "Marketing","Mumbai",   "Entry",  "Support marketing team with campaigns and research.",                         "MS Office,Social Media,Communication,Creativity",      10000, 18000,mkt));
        jobs.add(job("Chief Marketing Officer",     "Marketing","Delhi",    "Senior", "Lead overall marketing strategy and team.",                                   "Marketing Strategy,Leadership,Analytics,Branding",    200000,350000,mkt));

        // ── Legal (10 jobs) ───────────────────────────────────
        jobs.add(job("Corporate Lawyer",            "Legal","Mumbai",   "Senior", "Handle corporate legal matters and contracts.",                              "Corporate Law,Contract Drafting,LLB,Negotiation",     120000,200000,legal));
        jobs.add(job("Legal Associate",             "Legal","Delhi",    "Entry",  "Assist senior lawyers with research and drafting.",                          "Legal Research,Drafting,LLB,MS Office,Communication",  30000, 55000,legal));
        jobs.add(job("Compliance Manager",          "Legal","Bangalore","Senior", "Ensure company compliance with laws and regulations.",                       "Compliance,Regulatory,Risk Management,LLB",           100000,160000,legal));
        jobs.add(job("Intellectual Property Lawyer","Legal","Chennai",  "Senior", "Handle patents, trademarks and IP disputes.",                               "IP Law,Patent Filing,Trademark,LLB,Litigation",       130000,200000,legal));
        jobs.add(job("Legal Advisor",               "Legal","Hyderabad","Mid",    "Provide legal advice to management.",                                         "Legal Advisory,Contract Law,LLB,Communication",        70000,110000,legal));
        jobs.add(job("Paralegal",                   "Legal","Pune",     "Entry",  "Support lawyers with documentation and research.",                           "Legal Research,Documentation,MS Office,LLB",           20000, 38000,legal));
        jobs.add(job("Labour Law Consultant",       "Legal","Mumbai",   "Mid",    "Advise on employment and labour law matters.",                               "Labour Law,HR Compliance,LLB,Negotiation",             60000, 95000,legal));
        jobs.add(job("Contract Manager",            "Legal","Delhi",    "Mid",    "Draft, review and manage business contracts.",                               "Contract Management,Drafting,Negotiation,LLB",         65000,100000,legal));
        jobs.add(job("Litigation Lawyer",           "Legal","Bangalore","Senior", "Represent clients in court proceedings.",                                     "Litigation,Court Proceedings,LLB,Advocacy",           100000,180000,legal));
        jobs.add(job("Legal Intern",                "Legal","Chennai",  "Entry",  "Assist legal team with research and documentation.",                         "Legal Research,MS Office,Communication,LLB",            8000, 15000,legal));

        // ── Hospitality (10 jobs) ─────────────────────────────
        jobs.add(job("Hotel Manager",               "Hospitality","Mumbai",   "Senior", "Oversee all hotel operations and guest experience.",                        "Hotel Management,Leadership,Customer Service,Opera",   90000,140000,hotel));
        jobs.add(job("Front Desk Executive",        "Hospitality","Delhi",    "Entry",  "Manage guest check-in, check-out and queries.",                             "Customer Service,Opera PMS,Communication,MS Office",   18000, 30000,hotel));
        jobs.add(job("Executive Chef",              "Hospitality","Bangalore","Senior", "Lead kitchen operations and menu development.",                              "Culinary Arts,Menu Planning,Kitchen Management,HACCP", 80000,130000,hotel));
        jobs.add(job("Food and Beverage Manager",   "Hospitality","Chennai",  "Senior", "Manage F&B operations and team.",                                            "F&B Management,Cost Control,Leadership,Customer Service",80000,130000,hotel));
        jobs.add(job("Housekeeping Supervisor",     "Hospitality","Hyderabad","Mid",    "Supervise housekeeping staff and standards.",                                "Housekeeping,Team Management,Quality Control,Opera",    30000, 50000,hotel));
        jobs.add(job("Restaurant Manager",          "Hospitality","Pune",     "Mid",    "Manage restaurant operations and staff.",                                    "Restaurant Management,Customer Service,POS,Leadership", 45000, 75000,hotel));
        jobs.add(job("Bartender",                   "Hospitality","Mumbai",   "Entry",  "Prepare and serve beverages to guests.",                                     "Bartending,Mixology,Customer Service,Communication",   15000, 28000,hotel));
        jobs.add(job("Travel Consultant",           "Hospitality","Delhi",    "Entry",  "Plan and book travel itineraries for clients.",                              "Travel Planning,GDS,Customer Service,Communication",   18000, 35000,hotel));
        jobs.add(job("Event Coordinator",           "Hospitality","Bangalore","Mid",    "Coordinate hotel events and banquet operations.",                            "Event Management,Coordination,Vendor Management",      40000, 65000,hotel));
        jobs.add(job("Spa Therapist",               "Hospitality","Chennai",  "Entry",  "Provide spa and wellness treatments to guests.",                             "Spa Therapy,Massage,Customer Service,Wellness",        15000, 28000,hotel));

        // ── Media (10 jobs) ───────────────────────────────────
        jobs.add(job("Journalist",                  "Media","Mumbai",   "Mid",    "Research and write news articles.",                                          "Journalism,Writing,Research,Interviewing,MS Office",   35000, 60000,media));
        jobs.add(job("Film Director",               "Media","Delhi",    "Senior", "Direct film and video productions.",                                          "Direction,Screenplay,Production,Leadership,Creativity",100000,200000,media));
        jobs.add(job("Photographer",                "Media","Bangalore","Mid",    "Capture professional photos for media.",                                      "Photography,Lightroom,Photoshop,Composition",           40000, 70000,media));
        jobs.add(job("News Anchor",                 "Media","Chennai",  "Mid",    "Present news on television.",                                                 "Presenting,Communication,Journalism,Teleprompter",     50000, 90000,media));
        jobs.add(job("Radio Jockey",                "Media","Hyderabad","Entry",  "Host radio shows and engage listeners.",                                      "Communication,Voice,Creativity,Music,Scripting",       20000, 40000,media));
        jobs.add(job("Content Producer",            "Media","Pune",     "Mid",    "Produce digital content for online platforms.",                               "Content Production,Video Editing,YouTube,Social Media", 45000, 75000,media));
        jobs.add(job("Scriptwriter",                "Media","Mumbai",   "Mid",    "Write scripts for films, TV and digital media.",                              "Scriptwriting,Storytelling,Creativity,Final Draft",    40000, 70000,media));
        jobs.add(job("Animator",                    "Media","Delhi",    "Mid",    "Create 2D and 3D animations.",                                                "Maya,Blender,After Effects,3D Animation,Rigging",      50000, 85000,media));
        jobs.add(job("Sound Engineer",              "Media","Bangalore","Mid",    "Record, mix and master audio for productions.",                               "Pro Tools,Logic Pro,Sound Design,Mixing,Mastering",    45000, 75000,media));
        jobs.add(job("Media Planner",               "Media","Chennai",  "Mid",    "Plan and buy media placements for campaigns.",                                "Media Planning,Buying,Analytics,Excel,Communication",  55000, 90000,media));

        // ── Logistics (10 jobs) ───────────────────────────────
        jobs.add(job("Supply Chain Manager",        "Logistics","Mumbai",   "Senior", "Manage end-to-end supply chain operations.",                                "Supply Chain,SAP,Logistics,Vendor Management,Excel",  100000,160000,logis));
        jobs.add(job("Warehouse Manager",           "Logistics","Delhi",    "Mid",    "Oversee warehouse operations and inventory.",                                "Warehouse Management,WMS,Inventory,Leadership",        55000, 85000,logis));
        jobs.add(job("Logistics Coordinator",       "Logistics","Bangalore","Entry",  "Coordinate shipments and delivery schedules.",                               "Logistics,MS Office,Communication,ERP,Coordination",   22000, 38000,logis));
        jobs.add(job("Fleet Manager",               "Logistics","Chennai",  "Mid",    "Manage company vehicle fleet and drivers.",                                  "Fleet Management,GPS Tracking,Maintenance,Leadership",  50000, 80000,logis));
        jobs.add(job("Procurement Officer",         "Logistics","Hyderabad","Mid",    "Source and purchase goods and services.",                                    "Procurement,Vendor Management,Negotiation,SAP,Excel",   55000, 85000,logis));
        jobs.add(job("Import Export Executive",     "Logistics","Pune",     "Mid",    "Handle import/export documentation and compliance.",                         "Import Export,Customs,EXIM,Documentation,Incoterms",    40000, 65000,logis));
        jobs.add(job("Inventory Analyst",           "Logistics","Mumbai",   "Entry",  "Analyze and manage inventory levels.",                                       "Inventory Management,Excel,ERP,Data Analysis",          25000, 42000,logis));
        jobs.add(job("Freight Coordinator",         "Logistics","Delhi",    "Entry",  "Coordinate freight movements and documentation.",                            "Freight,Logistics,MS Office,Communication,ERP",         20000, 35000,logis));
        jobs.add(job("Operations Manager",          "Logistics","Bangalore","Senior", "Oversee daily logistics and distribution operations.",                       "Operations,Leadership,SAP,Process Improvement,Excel",   90000,140000,logis));
        jobs.add(job("Last Mile Delivery Manager",  "Logistics","Chennai",  "Mid",    "Manage last mile delivery operations.",                                      "Delivery Management,GPS,Team Management,Analytics",     55000, 85000,logis));

        jobRepository.saveAll(jobs);
        System.out.println("✅ " + jobs.size() + " jobs seeded across IT, Finance, Healthcare, Education, Engineering, Marketing, Legal, Hospitality, Media, Logistics.");
    }

    // ── Helpers ───────────────────────────────────────────────
    private User getOrCreate(String email, String name, String pass, User.Role role, String company) {
        return userRepository.findByEmail(email)
                .orElseGet(() -> userRepository.save(makeUser(name, email, pass, role, company)));
    }

    private User makeUser(String name, String email, String pass, User.Role role, String company) {
        User u = new User();
        u.setFullName(name);
        u.setEmail(email);
        u.setPassword(passwordEncoder.encode(pass));
        u.setRole(role);
        u.setCompanyName(company);
        return u;
    }

    private Job job(String title, String category, String location, String level,
                    String desc, String skills, double minSal, double maxSal, User employer) {
        Job j = new Job();
        j.setTitle(title);
        j.setCategory(category);
        j.setLocation(location);
        j.setExperienceLevel(level);
        j.setDescription(desc);
        j.setSkillsRequired(skills);
        j.setSalaryMin(minSal);
        j.setSalaryMax(maxSal);
        j.setEmployer(employer);
        j.setActive(true);
        return j;
    }
}
