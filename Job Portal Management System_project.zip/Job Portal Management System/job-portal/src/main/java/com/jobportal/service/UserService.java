package com.jobportal.service;

import com.jobportal.entity.User;
import com.jobportal.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.*;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public User register(User user) {
        if (userRepository.existsByEmail(user.getEmail())) {
            throw new RuntimeException("Email already registered");
        }
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        return userRepository.save(user);
    }

    public User findByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));
    }

    public User findById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));
    }

    public User updateProfile(User updated) {
        User existing = findById(updated.getId());
        existing.setFullName(updated.getFullName());
        existing.setPhone(updated.getPhone());
        existing.setLocation(updated.getLocation());
        existing.setCompanyName(updated.getCompanyName());
        existing.setBio(updated.getBio());
        existing.setSkills(updated.getSkills());
        existing.setLinkedinUrl(updated.getLinkedinUrl());
        existing.setGithubUrl(updated.getGithubUrl());
        existing.setPortfolioUrl(updated.getPortfolioUrl());
        existing.setCurrentJobTitle(updated.getCurrentJobTitle());
        existing.setExperienceYears(updated.getExperienceYears());
        existing.setEducation(updated.getEducation());
        existing.setLanguages(updated.getLanguages());
        existing.setDateOfBirth(updated.getDateOfBirth());
        existing.setGender(updated.getGender());
        return userRepository.save(existing);
    }

    public String saveResume(Long userId, MultipartFile file, String uploadDir) throws IOException {
        Path dir = Paths.get(uploadDir);
        if (!Files.exists(dir)) Files.createDirectories(dir);

        String filename = "resume_" + userId + "_" + file.getOriginalFilename();
        Path target = dir.resolve(filename);
        Files.copy(file.getInputStream(), target, StandardCopyOption.REPLACE_EXISTING);

        User user = findById(userId);
        user.setResumePath(target.toString());
        userRepository.save(user);
        return filename;
    }
}
