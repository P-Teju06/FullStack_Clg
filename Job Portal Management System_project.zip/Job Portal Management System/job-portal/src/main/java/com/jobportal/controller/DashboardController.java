package com.jobportal.controller;

import com.jobportal.entity.User;
import com.jobportal.entity.Application;
import com.jobportal.service.*;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
@RequiredArgsConstructor
public class DashboardController {

    private final UserService userService;
    private final JobService jobService;
    private final ApplicationService applicationService;

    @GetMapping("/dashboard")
    public String dashboard(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User user = userService.findByEmail(userDetails.getUsername());
        model.addAttribute("user", user);

        switch (user.getRole()) {
            case STUDENT -> {
                var applications = applicationService.getApplicationsByUser(user);
                long shortlisted = applications.stream().filter(a -> a.getStatus() == Application.Status.SHORTLISTED).count();
                long pending     = applications.stream().filter(a -> a.getStatus() == Application.Status.PENDING).count();
                long rejected    = applications.stream().filter(a -> a.getStatus() == Application.Status.REJECTED).count();
                model.addAttribute("applications", applications);
                model.addAttribute("shortlistedCount", shortlisted);
                model.addAttribute("pendingCount", pending);
                model.addAttribute("rejectedCount", rejected);
                return "student/dashboard";
            }
            case EMPLOYER -> {
                var jobs = jobService.getJobsByEmployer(user);
                model.addAttribute("jobs", jobs);
                model.addAttribute("totalJobs", jobs.size());
                long totalApps        = jobs.stream().mapToLong(applicationService::countByJob).sum();
                long totalShortlisted = jobs.stream().mapToLong(applicationService::countShortlisted).sum();
                model.addAttribute("totalApplications", totalApps);
                model.addAttribute("totalShortlisted", totalShortlisted);
                return "employer/dashboard";
            }
            case ADMIN -> { return "redirect:/admin/dashboard"; }
            default    -> { return "redirect:/"; }
        }
    }

    @GetMapping("/")
    public String home() {
        return "redirect:/jobs";
    }
}
