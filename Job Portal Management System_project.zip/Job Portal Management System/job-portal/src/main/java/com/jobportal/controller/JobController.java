package com.jobportal.controller;

import com.jobportal.entity.Job;
import com.jobportal.entity.User;
import com.jobportal.service.JobService;
import com.jobportal.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequiredArgsConstructor
public class JobController {

    private final JobService jobService;
    private final UserService userService;

    // Public job listing with search/filter
    @GetMapping("/jobs")
    public String listJobs(@RequestParam(required = false) String keyword,
                           @RequestParam(required = false) String category,
                           @RequestParam(required = false) String location,
                           @RequestParam(required = false) String experience,
                           Model model) {
        var jobs = jobService.searchJobs(keyword, category, location, experience);
        model.addAttribute("jobs", jobs);
        model.addAttribute("keyword", keyword);
        model.addAttribute("category", category);
        model.addAttribute("location", location);
        model.addAttribute("experience", experience);
        return "jobs/list";
    }

    @GetMapping("/jobs/{id}")
    public String jobDetail(@PathVariable Long id, Model model) {
        model.addAttribute("job", jobService.findById(id));
        return "jobs/detail";
    }

    // Employer: post job
    @GetMapping("/employer/jobs/new")
    public String newJobForm(Model model) {
        model.addAttribute("job", new Job());
        return "employer/job-form";
    }

    @PostMapping("/employer/jobs/new")
    public String postJob(@Valid @ModelAttribute("job") Job job,
                          BindingResult result,
                          @AuthenticationPrincipal UserDetails userDetails,
                          Model model) {
        if (result.hasErrors()) return "employer/job-form";
        User employer = userService.findByEmail(userDetails.getUsername());
        job.setEmployer(employer);
        jobService.postJob(job);
        return "redirect:/dashboard";
    }

    // Employer: edit job
    @GetMapping("/employer/jobs/{id}/edit")
    public String editJobForm(@PathVariable Long id, Model model) {
        model.addAttribute("job", jobService.findById(id));
        return "employer/job-form";
    }

    @PostMapping("/employer/jobs/{id}/edit")
    public String updateJob(@PathVariable Long id,
                            @Valid @ModelAttribute("job") Job job,
                            BindingResult result) {
        if (result.hasErrors()) return "employer/job-form";
        job.setId(id);
        jobService.updateJob(job);
        return "redirect:/dashboard";
    }

    // Employer: delete job
    @PostMapping("/employer/jobs/{id}/delete")
    public String deleteJob(@PathVariable Long id) {
        jobService.deleteJob(id);
        return "redirect:/dashboard";
    }
}
