package com.jobportal.controller;

import com.jobportal.entity.Application;
import com.jobportal.entity.Job;
import com.jobportal.entity.User;
import com.jobportal.service.*;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@Controller
@RequiredArgsConstructor
public class ApplicationController {

    private final ApplicationService applicationService;
    private final JobService jobService;
    private final UserService userService;

    @Value("${app.upload.dir}")
    private String uploadDir;

    // Student: apply for a job
    @GetMapping("/student/jobs/{jobId}/apply")
    public String applyForm(@PathVariable Long jobId, Model model) {
        model.addAttribute("job", jobService.findById(jobId));
        return "student/apply";
    }

    @PostMapping("/student/jobs/{jobId}/apply")
    public String applySubmit(@PathVariable Long jobId,
                              @RequestParam String coverLetter,
                              @RequestParam(required = false) MultipartFile resume,
                              @AuthenticationPrincipal UserDetails userDetails) throws IOException {
        User student = userService.findByEmail(userDetails.getUsername());
        Job job = jobService.findById(jobId);

        if (resume != null && !resume.isEmpty()) {
            userService.saveResume(student.getId(), resume, uploadDir);
        }
        applicationService.apply(job, student, coverLetter);
        return "redirect:/student/applications";
    }

    // Student: view own applications
    @GetMapping("/student/applications")
    public String myApplications(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User student = userService.findByEmail(userDetails.getUsername());
        model.addAttribute("applications", applicationService.getApplicationsByUser(student));
        return "student/applications";
    }

    // Employer: view applicants for a job
    @GetMapping("/employer/jobs/{jobId}/applicants")
    public String viewApplicants(@PathVariable Long jobId, Model model) {
        Job job = jobService.findById(jobId);
        model.addAttribute("job", job);
        model.addAttribute("applications", applicationService.getApplicationsByJob(job));
        return "employer/applicants";
    }

    // Employer: update application status
    @PostMapping("/employer/applications/{id}/status")
    public String updateStatus(@PathVariable Long id,
                               @RequestParam Application.Status status,
                               @RequestParam Long jobId) {
        applicationService.updateStatus(id, status);
        return "redirect:/employer/jobs/" + jobId + "/applicants";
    }

    // Student: upload resume from profile
    @PostMapping("/student/resume/upload")
    public String uploadResume(@RequestParam MultipartFile resume,
                               @AuthenticationPrincipal UserDetails userDetails) throws IOException {
        User student = userService.findByEmail(userDetails.getUsername());
        userService.saveResume(student.getId(), resume, uploadDir);
        return "redirect:/student/profile";
    }

    // Student: profile page
    @GetMapping("/student/profile")
    public String studentProfile(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User student = userService.findByEmail(userDetails.getUsername());
        model.addAttribute("user", student);
        return "student/profile";
    }

    @PostMapping("/student/profile")
    public String updateStudentProfile(@ModelAttribute User updated,
                                       @AuthenticationPrincipal UserDetails userDetails) {
        User student = userService.findByEmail(userDetails.getUsername());
        updated.setId(student.getId());
        userService.updateProfile(updated);
        return "redirect:/student/profile?updated";
    }
}
