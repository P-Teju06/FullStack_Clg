INSERT INTO users (full_name, email, password, role)
VALUES ('Admin', 'admin@jobportal.com', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'ADMIN');
